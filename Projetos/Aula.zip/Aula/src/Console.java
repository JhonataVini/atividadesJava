import java.util.Scanner;

public class Console {

	void executa(){
		Scanner entrada = new Scanner(System.in);
		IMC imc= new IMC();
		
		System.out.print("Digite seu Nome: ");
		String nome = entrada.nextLine();
		
		System.out.print("Digite seu peso: ");
		double peso = entrada.nextDouble();
		
		System.out.print("Digite sua Altura: ");
		double altura = entrada.nextDouble();
		
		double indice= imc.getIndice(peso, altura);
		
		
		System.out.println(nome);
		System.out.println("Seu IMC �: "+ indice);
		System.out.println("Sua avalia��o �: "+imc.getSituacao(indice));
		
	}
	
	
}
