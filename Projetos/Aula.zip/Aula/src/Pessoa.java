
public class Pessoa {

	String nome;
	double peso;
	double altura;
	
	
	
}
