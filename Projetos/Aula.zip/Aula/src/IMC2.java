
public class IMC2 {
	double getIndice(Pessoa p){
		
		double indice;
		
		indice = p.peso/(p.altura *p.altura);
		
		return indice;
		
	}
	
String getSituacao(double indice){
		
		String situacao;
		
		if (indice >=30){
			situacao= "Cuidado, acima do peso!";
			
		}else {
			situacao = "Cuidado, abaixo do peso!";	
				}
			
		
		return situacao;
		
	}
}
