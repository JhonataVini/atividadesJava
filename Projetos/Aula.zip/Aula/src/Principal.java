/**
 * 
 * @author jhonata.lopes.a
 *
 */
public class Principal {

	public static void main(String[] args) {
      Console console = new Console();
      console.executa();
		
		
	}

}
