
public class IMC {
	double getIndice(double peso, double altura){
		
		double indice;
		
		indice = peso/(altura *altura);
		
		return indice;
		
	}
	
String getSituacao(double indice){
		
		String situacao;
		
		if (indice >=30){
			situacao= "Cuidado, acima do peso!";
			
		}else {
			situacao = "Cuidado, abaixo do peso!";	
				}
			
		
		return situacao;
		
	}
}
